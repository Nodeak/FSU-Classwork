package edu.fsu.cs.hw5;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

public class MainFragment extends Fragment{

    private OnFragmentInteractionListener mListener;

    public MainFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_main, container, false);

        // TODO: setup UI
        Button login_button = (Button) rootView.findViewById(R.id.login_button);
        Button register_button = (Button) rootView.findViewById(R.id.submit_button);

        login_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity activity = (MainActivity) getActivity();
                activity.onStartLogin();
                //Toast.makeText(getContext(), "Register clicked.", Toast.LENGTH_LONG).show();
            }
        });
        register_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity activity = (MainActivity) getActivity();
                activity.onStartRegister();
                //Toast.makeText(getContext(), "Register clicked.", Toast.LENGTH_LONG).show();
            }
        });

        return rootView;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnFragmentInteractionListener {
        void onStartLogin();
        void onStartRegister();
    }

    public void toLogin(){
        MainActivity activity = (MainActivity) getActivity();
        activity.onStartLogin();
        Toast.makeText(getContext(), "Login clicked.", Toast.LENGTH_LONG).show();
    }

    public void toRegister(){
        MainActivity activity = (MainActivity) getActivity();
        activity.onStartRegister();
        Toast.makeText(getContext(), "Register clicked.", Toast.LENGTH_LONG).show();
    }
}