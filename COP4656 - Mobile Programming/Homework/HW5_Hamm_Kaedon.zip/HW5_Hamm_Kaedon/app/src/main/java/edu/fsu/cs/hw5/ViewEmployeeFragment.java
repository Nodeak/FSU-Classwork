package edu.fsu.cs.hw5;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class ViewEmployeeFragment extends Fragment {
    private OnUserFragmentInteractionListener mListener;
    public static final String ARG_URI = "uri";
    TextView idView;
    TextView nameView;
    TextView emailView;
    TextView genderView;
    TextView departmentView;
    String id, name, email, gender, department;
    Button mLogout;
    Button mDeleteAccount;

    public static ViewEmployeeFragment getInstance(Uri uri) {
        ViewEmployeeFragment fragment = new ViewEmployeeFragment();
        Bundle data = new Bundle();
        data.putParcelable(ARG_URI, uri);
        fragment.setArguments(data);
        return fragment;
    }

    public ViewEmployeeFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // TODO: Get arguments
        Bundle bundle = getArguments();
        Uri uri = bundle.getParcelable(ARG_URI);
        String emplid = bundle.getString("emplid");
        Log.i("URI", uri.toString());
        String[] mProjection = {MyContentProvider.COLUMN_EMPLOYEEID,
                                MyContentProvider.COLUMN_NAME,
                                MyContentProvider.COLUMN_EMAIL,
                                MyContentProvider.COLUMN_GENDER,
                                MyContentProvider.COLUMN_DEPARTMENT};
        String mSelection = MyContentProvider.COLUMN_ID + " = ? ";
        String[] mSelectionArgs = {uri.getLastPathSegment().trim()};
        Log.i("URI", uri.getLastPathSegment().trim());
        Cursor mCursor = getActivity().getContentResolver().query(MyContentProvider.CONTENT_URI, mProjection, mSelection, mSelectionArgs, null);
        mCursor.moveToFirst();
        id = mCursor.getString(mCursor.getColumnIndex(MyContentProvider.COLUMN_EMPLOYEEID));
        name = mCursor.getString(mCursor.getColumnIndex(MyContentProvider.COLUMN_NAME));
        email = mCursor.getString(mCursor.getColumnIndex(MyContentProvider.COLUMN_EMAIL));
        gender = mCursor.getString(mCursor.getColumnIndex(MyContentProvider.COLUMN_GENDER));
        department = mCursor.getString(mCursor.getColumnIndex(MyContentProvider.COLUMN_DEPARTMENT));

        mCursor.close();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.fragment_user, container, false);
        // TODO: setup UI
        idView = (TextView) rootView.findViewById(R.id.id_var);
        nameView = (TextView) rootView.findViewById(R.id.name_var);
        emailView = (TextView) rootView.findViewById(R.id.email_var);
        genderView = (TextView) rootView.findViewById(R.id.gender_var);
        departmentView = (TextView) rootView.findViewById(R.id.department_var);
        mLogout = (Button) rootView.findViewById(R.id.logout_button);
        mDeleteAccount = (Button) rootView.findViewById(R.id.delete_button);

        idView.setText(id);
        nameView.setText(name);
        emailView.setText(email);
        genderView.setText(gender);
        departmentView.setText(department);

        mLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity activity = (MainActivity) getActivity();
                activity.onLoggedOut();
            }
        });

        mDeleteAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Can use ID because it is also a unique data point in the SQLite DB
                String where = MyContentProvider.COLUMN_EMPLOYEEID + " = ? ";
                String[] selectionArgs = {id};
                int deleted = getActivity().getContentResolver().delete(MyContentProvider.CONTENT_URI, where, selectionArgs);
                Log.i("DELETED", String.valueOf(deleted));
                if (deleted == 2){
                    MainActivity activity = (MainActivity) getActivity();
                    activity.onUserDeleted(deleted);
                }
                else{
                    Toast.makeText(getActivity(), "Deletion not successul", Toast.LENGTH_SHORT).show();
                }


            }
        });


        return rootView;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnUserFragmentInteractionListener) {
            mListener = (OnUserFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnUserFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnUserFragmentInteractionListener {
        void onLoggedOut();
        void onUserDeleted(int res);
    }
}
