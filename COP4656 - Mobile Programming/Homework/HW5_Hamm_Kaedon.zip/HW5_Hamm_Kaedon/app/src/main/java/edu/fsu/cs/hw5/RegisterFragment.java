package edu.fsu.cs.hw5;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class RegisterFragment extends Fragment {

    private OnRegisterFragmentInteractionListener mListener;

    private View mRootView;
    EditText idInput;
    EditText nameInput;
    EditText emailInput;
    EditText accessInput;
    EditText confirmInput;
    Spinner departmentInput;
    RadioButton maleRadio;
    RadioButton femaleRadio;
    CheckBox agreeBox;
    Button submitButton;
    Button resetButton;
    RadioGroup radioGroup;

    public RegisterFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mRootView = inflater.inflate(R.layout.fragment_register, container, false);
        // TODO: Setup UI
        idInput = (EditText) mRootView.findViewById(R.id.id_input);
        nameInput = (EditText) mRootView.findViewById(R.id.name_input);
        emailInput = (EditText) mRootView.findViewById(R.id.email_input);
        accessInput = (EditText) mRootView.findViewById(R.id.access_input);
        confirmInput = (EditText) mRootView.findViewById(R.id.confirm_input);
        departmentInput = (Spinner) mRootView.findViewById(R.id.department_input);
        maleRadio = (RadioButton) mRootView.findViewById(R.id.male_radio);
        femaleRadio = (RadioButton) mRootView.findViewById(R.id.female_radio);
        agreeBox = (CheckBox) mRootView.findViewById(R.id.agree_checkl);
        submitButton = (Button) mRootView.findViewById(R.id.submit_button);
        resetButton = (Button) mRootView.findViewById(R.id.reset_button);
        radioGroup = (RadioGroup) mRootView.findViewById(R.id.gender_group);

        final ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this.getActivity(),
                R.array.department_list, android.R.layout.simple_spinner_item);
        departmentInput.setAdapter(adapter);

        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                idInput.setText(null);
                nameInput.setText(null);
                emailInput.setText(null);
                accessInput.setText(null);
                confirmInput.setText(null);
                radioGroup.clearCheck();
                agreeBox.setChecked(false);
                departmentInput.setSelection(0);

            }
        });

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity activity = (MainActivity) getActivity();
                String id = idInput.getText().toString();
                boolean idCheck = true;
                idCheck = check_existing_ids(id);

                if (idInput.getText().toString().matches("")){
                    Toast.makeText(getActivity(),
                            "Please input your Employee ID", Toast.LENGTH_SHORT).show(); return;}
                else if (nameInput.getText().toString().matches("")){
                    Toast.makeText(getActivity(),
                            "Please input your Name", Toast.LENGTH_SHORT).show(); return;}
                else if (emailInput.getText().toString().matches("")){
                    Toast.makeText(getActivity(),
                            "Please input your email", Toast.LENGTH_SHORT).show(); return;}
                else if (!maleRadio.isChecked() && !femaleRadio.isChecked()){
                    Toast.makeText(getActivity(),
                            "Please select a gender", Toast.LENGTH_SHORT).show(); return;}
                else if (accessInput.getText().toString().matches("")){
                    Toast.makeText(getActivity(),
                            "Please input an access code", Toast.LENGTH_SHORT).show(); return;}
                else if (confirmInput.getText().toString().matches("")){
                    Toast.makeText(getActivity(),
                            "Please confirm access code", Toast.LENGTH_SHORT).show(); return;}
                else if (departmentInput.getSelectedItem().toString().matches("")){
                    Toast.makeText(getActivity(),
                            "Please confirm access code", Toast.LENGTH_SHORT).show(); return;}
                else if (!agreeBox.isChecked()){
                    Toast.makeText(getActivity(),
                            "Please agree to the Terms and Services", Toast.LENGTH_SHORT).show(); return;}
                else if (!confirmInput.getText().toString().matches(accessInput.getText().toString())){
                    Toast.makeText(getActivity(),
                            "Please ensure that the code confirmation is inputted " +
                                    "correctly", Toast.LENGTH_SHORT).show(); return;}
                else if (!idCheck){
                    return;
                }

                ContentValues mNewValues = new ContentValues();
                Uri mNewUri;

                mNewValues.put(MyContentProvider.COLUMN_EMPLOYEEID, idInput.getText().toString().trim());
                mNewValues.put(MyContentProvider.COLUMN_NAME, nameInput.getText().toString().trim());
                mNewValues.put(MyContentProvider.COLUMN_EMAIL, emailInput.getText().toString().trim());
                mNewValues.put(MyContentProvider.COLUMN_GENDER, radioGroup.getCheckedRadioButtonId());
                mNewValues.put(MyContentProvider.COLUMN_PASSWD, accessInput.getText().toString().trim());
                mNewValues.put(MyContentProvider.COLUMN_DEPARTMENT, departmentInput.getSelectedItem().toString().trim());
                Log.i("INSERT", "filled in mNewValue");
                mNewUri = getActivity().getContentResolver().insert(MyContentProvider.CONTENT_URI, mNewValues);
                try {
                    mNewUri = getActivity().getContentResolver().insert(MyContentProvider.CONTENT_URI, mNewValues);
                    //Log.i("INSERT", mNewUri.toString());
                }
                catch(Exception e){
                    Log.i("INSERT", e.toString());
                }
                //mNewUri = mainActivity.getContentResolver().insert(MyContentProvider.CONTENT_URI, mNewValues);
                activity.onLoggedIn(mNewUri);
                Toast.makeText(getActivity(), "Employee Account Created", Toast.LENGTH_LONG).show();
            }
        });

        return mRootView;
    }

    public boolean check_existing_ids(String id){
        String[] mProjection = new String[]{MyContentProvider.COLUMN_EMPLOYEEID};
        String mSelection = MyContentProvider.COLUMN_EMPLOYEEID + " = ? ";
        String[] selectionArgs = new String[]{id};
        Cursor mCursor = getActivity().getContentResolver().query(MyContentProvider.CONTENT_URI, mProjection, mSelection, selectionArgs, null);
        mCursor.moveToFirst();
        if (mCursor.getCount() > 0 && mCursor.getString(mCursor.getColumnIndex(MyContentProvider.COLUMN_EMPLOYEEID)) != null){
            if (mCursor.getString(mCursor.getColumnIndex(MyContentProvider.COLUMN_EMPLOYEEID)).equals(id))
                Toast.makeText(getActivity(), "EmployeeID Already Exists.", Toast.LENGTH_LONG).show();
            mCursor.close();
            return false;

        }
        return true;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnRegisterFragmentInteractionListener) {
            mListener = (OnRegisterFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnRegisterFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnRegisterFragmentInteractionListener {
        void onSubmit(ContentValues values);
    }

}
