package edu.fsu.cs.hw5;

import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements
        MainFragment.OnFragmentInteractionListener, LoginFragment.OnLoginFragmentInteractionListener,
        RegisterFragment.OnRegisterFragmentInteractionListener,
        ViewEmployeeFragment.OnUserFragmentInteractionListener{

    private static final String TAG = MainActivity.class.getCanonicalName();
    FragmentTransaction transaction;
    FragmentManager fragmentManager;
    Cursor mCursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        onMain();
    }

    public void onMain() {
        MainFragment fragment = new MainFragment();
        String tag = MainFragment.class.getCanonicalName();
        transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_frame_main, fragment, TAG);
        transaction.commit();
    }

    @Override
    public void onLoggedIn(Uri uri) {
        // TODO: User logged in
        Log.i("LOGIN", "Entered onLogin()");
        ViewEmployeeFragment viewEmployeeFragment = ViewEmployeeFragment.getInstance(uri);
        transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_frame_main, viewEmployeeFragment, TAG);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    @Override
    public void onSubmit(ContentValues values) {
        // TODO: User registered
        Log.i("SUBMIT", "Entered onSubmit()");
        LoginFragment loginFrament = new LoginFragment();
        transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_frame_main, loginFrament, TAG);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    @Override
    public void onStartLogin() {
        // TODO: Start LoginFragment
        Log.i("LOGIN", "Entered onStartLogin()");
        LoginFragment loginFrament = new LoginFragment();
        transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_frame_main, loginFrament, TAG);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    @Override
    public void onStartRegister() {
        // TODO: Start RegisterFragment
        Log.i("REGISTER", "Entered onStartRegister()");
        RegisterFragment registerFragment = new RegisterFragment();
        transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_frame_main, registerFragment, TAG);
        transaction.addToBackStack(null);
        transaction.commit();
    }


    @Override
    public void onLoggedOut() {
        // TODO: User logged out
        Log.i("LOGOUT", "Entered onLoggedOut()");
        MainFragment mainFragment = new MainFragment();
        transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_frame_main, mainFragment, TAG);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    @Override
    public void onUserDeleted(int res) {
        // TODO: User account deleted
        Log.i("DELETE", "Entered onUserDeleted()");
        MainFragment mainFragment = new MainFragment();
        transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_frame_main, mainFragment, TAG);
        transaction.addToBackStack(null);
        transaction.commit();
        Toast.makeText(this, "Account Deleted.", Toast.LENGTH_SHORT).show();

    }

}
