package edu.fsu.cs.hw5;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginFragment extends Fragment {
    private OnLoginFragmentInteractionListener mListener;

    EditText emplid_field;
    EditText access_field;
    Button login_button;


    public LoginFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.fragment_login, container, false);
        // TODO: Setup UI
        emplid_field = (EditText) rootView.findViewById(R.id.id_field);
        access_field = (EditText) rootView.findViewById(R.id.access_field);
        login_button = (Button) rootView.findViewById(R.id.login_button);

        login_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Toast.makeText(getActivity(), "Entered Login Button push", Toast.LENGTH_SHORT).show();
                int idcheck = checkCredentials(emplid_field.getText().toString(), access_field.getText().toString());
                if(idcheck > -1){
                    Uri uri = Uri.withAppendedPath(MyContentProvider.CONTENT_URI, "" + idcheck);
                    MainActivity mainActivity = (MainActivity) getActivity();
                    mainActivity.onLoggedIn(uri);
                }
            }
        });
        return rootView;
    }

    public int checkCredentials(String emplid, String passwd){
        String[] mProjection = new String[]{MyContentProvider.COLUMN_ID,
                                            MyContentProvider.COLUMN_EMPLOYEEID,
                                            MyContentProvider.COLUMN_PASSWD};
        String mSelection = MyContentProvider.COLUMN_EMPLOYEEID + " = ? ";
        String[] selectionArgs = new String[]{emplid};
        Cursor mCursor = getActivity().getContentResolver().query(MyContentProvider.CONTENT_URI, mProjection, mSelection, selectionArgs, null);
        mCursor.moveToFirst();
        if (mCursor.getCount() > 0 && mCursor.getString(mCursor.getColumnIndex(MyContentProvider.COLUMN_EMPLOYEEID)) != null){
            if (mCursor.getString(mCursor.getColumnIndex(MyContentProvider.COLUMN_EMPLOYEEID)).equals(emplid)){
                if (mCursor.getString(mCursor.getColumnIndex(MyContentProvider.COLUMN_PASSWD)).equals(passwd)){
                    return mCursor.getInt(mCursor.getColumnIndex(MyContentProvider.COLUMN_ID));
                }
            }
            Toast.makeText(getActivity(), "Access code doesn't match.", Toast.LENGTH_SHORT).show();
            return -1;
        }
        Toast.makeText(getActivity(), "EmployeeID not found.", Toast.LENGTH_SHORT).show();
        return -1;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnLoginFragmentInteractionListener) {
            mListener = (OnLoginFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnRegisterFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnLoginFragmentInteractionListener {
        void onLoggedIn(Uri uri);
    }
}