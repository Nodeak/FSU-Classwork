package edu.fsu.cs.hw3;

import android.annotation.TargetApi;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.Telephony;
import android.telephony.SmsMessage;
import android.util.Log;
import android.widget.Toast;

public class SmsReceiver extends BroadcastReceiver {

    public SmsReceiver() {
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        String url = extractUrlFromIntent(intent);
        String url_ending = url.substring((url.length()-4));
        Log.i("EndURL", url_ending);
        if(url_ending.equals(".com")){
            Bundle bundle = new Bundle();
            bundle.putString("newUrl", url);
            Intent maIntent = new Intent();
            maIntent.setClassName(context, "MainActivity.class");
            intent.putExtras(bundle);
            context.startActivity(intent);
        }
        else{
            Toast.makeText(context, "Please provide a valid url", Toast.LENGTH_LONG).show();
        }
    }

    @TargetApi(Build.VERSION_CODES.KITKAT)
    public static String extractUrlFromIntent(Intent intent) {
        Log.d("SAVAGE", "Message received.");
        SmsMessage[] messages = Telephony.Sms.Intents.getMessagesFromIntent(intent);
        String url = "";
        for (int i = 0; i < messages.length; i++) {
            String messagebody = messages[i].getMessageBody();
            url += messagebody;
        }
        return url;
    }
}