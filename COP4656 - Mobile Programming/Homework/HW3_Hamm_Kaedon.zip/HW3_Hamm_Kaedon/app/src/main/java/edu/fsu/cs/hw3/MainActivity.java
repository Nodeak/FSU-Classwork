package edu.fsu.cs.hw3;

import android.Manifest;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.IntentFilter;
import android.os.Bundle;
import android.app.Activity;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.provider.Telephony;
import android.view.View;


public class MainActivity extends Activity {

    private static final String TAG = MainActivity.class.getCanonicalName();
    private int MY_PERMISSIONS_REQUEST_SMS_RECEIVE = 10;
    UrlListFragment uFragment;
    MyWebFragment wFragment;
    FragmentManager frag_manager;
    FragmentTransaction transaction;



    @Override
    protected void onCreate(Bundle savedInstanceState) {

        // Sets permissions again in case Manifest didn't like it the first time
        // https://stackoverflow.com/questions/47678283/sms-broadcastreceiver-on-oreo
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.RECEIVE_SMS},
                MY_PERMISSIONS_REQUEST_SMS_RECEIVE);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        uFragment = new UrlListFragment();
        wFragment = new MyWebFragment();

        Bundle url_extras = new Bundle();   // Will send links to URL Fragment
        Bundle web_extras = new Bundle();   // Will send clicked link to WebView Fragment

        // Manager transfers Bundle to URLFragment
        frag_manager = getFragmentManager();
        Bundle args = getIntent().getExtras();
        if(args != null){
            newUrl(args.getString("newUrl"));
        }

    }

    public void linkClicked(String url){
        if(!url.substring(0,7).equals("http://")){
            url = "http://" + url;
        }
        MyWebFragment newWebFrag = new MyWebFragment();
        Bundle web_extra = new Bundle();
        web_extra.putString("url", url);
        newWebFrag.setArguments(web_extra);

        transaction = frag_manager.beginTransaction();
        transaction.replace(R.id.mywebfrag, newWebFrag);
        transaction.commit();
        wFragment = newWebFrag;
    }

    public void newUrl(String url){
        UrlListFragment newUrlFrag = new UrlListFragment();
        newUrlFrag.addUrlToList(url);
        transaction = frag_manager.beginTransaction();
        transaction.replace(R.id.urlfrag, newUrlFrag);
        transaction.commit();
        uFragment = newUrlFrag;
    }
}

