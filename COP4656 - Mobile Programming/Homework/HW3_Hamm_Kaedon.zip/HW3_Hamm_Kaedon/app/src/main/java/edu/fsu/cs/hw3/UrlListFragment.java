package edu.fsu.cs.hw3;

import android.app.Fragment;
import android.app.FragmentManager;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.lang.String;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class UrlListFragment extends Fragment {
    String[] defaultLinks = {"http://www.google.com", "http://www.netflix.com", "www.hulu.com"};
    String[] urlLinks;
    ListView listview;
    MyWebFragment webFrag;

    private static final String TAG = UrlListFragment.class.getCanonicalName();

    public UrlListFragment() {}

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // TODO: Handle new url if received in SmsReceiver
        urlLinks = defaultLinks;

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_url_list, container, false);


        // Setup ListView
        listview = (ListView) view.findViewById(R.id.linkedlist);
        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(view.getContext(), android.R.layout.simple_list_item_1, urlLinks);
        listview.setAdapter(adapter);


        // Listen for links clicked in ListView, send to link handler in Main
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Log.d("SAVAGE",urlLinks[i]);
                MainActivity activity = (MainActivity) getActivity();
                activity.linkClicked(urlLinks[i]);
            }
        });

        return view;
    }

    public void addUrlToList(String url){
        String[] tempArray = {"https://www.google.com", "http://www.netflix.com", "www.hulu.com",
                                        url};
        urlLinks = tempArray;
        MainActivity activity = (MainActivity) getActivity();
        activity.linkClicked(url);
    }
}
