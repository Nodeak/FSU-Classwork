package edu.fsu.cs.hw2_hamm_kaedon;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

public class RelativeLayoutActivity extends Activity {
    EditText idInput;
    EditText nameInput;
    EditText emailInput;
    EditText accessInput;
    EditText confirmInput;
    Spinner departmentInput;
    RadioButton maleRadio;
    RadioButton femaleRadio;
    CheckBox agreeBox;
    Button registerButton;
    Button resetButton;
    Button linear_Button;
    Button relative_Button;
    Button table_Button;
    RadioGroup radioGroup;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_relative_layout);

        // setting up all inputs
        idInput = findViewById(R.id.id_input);
        nameInput = findViewById(R.id.name_input);
        emailInput = findViewById(R.id.email_input);
        accessInput = findViewById(R.id.access_input);
        confirmInput = findViewById(R.id.confirm_input);
        departmentInput = findViewById(R.id.department_input);
        maleRadio = findViewById(R.id.male_radio);
        femaleRadio = findViewById(R.id.female_radio);
        agreeBox = findViewById(R.id.agree_checkl);
        registerButton = findViewById(R.id.register_button);
        resetButton = findViewById(R.id.reset_button);
        linear_Button = findViewById(R.id.to_linear_layout);
        relative_Button = findViewById(R.id.to_relative_layout);
        table_Button = findViewById(R.id.to_table_layout);

        // create adapter for spinner and set it
        final ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.department_list, android.R.layout.simple_spinner_item);
        departmentInput.setAdapter(adapter);

        // reset button will set all options back to their default state
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                idInput.setText(null);
                nameInput.setText(null);
                emailInput.setText(null);
                accessInput.setText(null);
                confirmInput.setText(null);
                radioGroup.clearCheck();
                agreeBox.setChecked(false);
                departmentInput.setSelection(0);



                Toast.makeText(getApplicationContext(), "Reset", Toast.LENGTH_LONG).show();

            }
        });



        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String[] empids = getResources().getStringArray(R.array.empids);
                boolean idCheck = false;
                String id = idInput.getText().toString();

                for (String i : empids) {
                    if (i.matches(id)) {
                        idCheck = true;
                    }
                }

                if (idInput.getText().toString().matches("")){
                    Toast.makeText(getApplicationContext(),
                            "Please input your Employee ID", Toast.LENGTH_SHORT).show(); return;}
                else if (nameInput.getText().toString().matches("")){
                    Toast.makeText(getApplicationContext(),
                            "Please input your Name", Toast.LENGTH_SHORT).show(); return;}
                else if (emailInput.getText().toString().matches("")){
                    Toast.makeText(getApplicationContext(),
                            "Please input your email", Toast.LENGTH_SHORT).show(); return;}
                else if (!maleRadio.isChecked() && !femaleRadio.isChecked()){
                    Toast.makeText(getApplicationContext(),
                            "Please select a gender", Toast.LENGTH_SHORT).show(); return;}
                else if (accessInput.getText().toString().matches("")){
                    Toast.makeText(getApplicationContext(),
                            "Please input an access code", Toast.LENGTH_SHORT).show(); return;}
                else if (confirmInput.getText().toString().matches("")){
                    Toast.makeText(getApplicationContext(),
                            "Please confirm access code", Toast.LENGTH_SHORT).show(); return;}
                else if (departmentInput.getSelectedItem().toString().matches("")){
                    Toast.makeText(getApplicationContext(),
                            "Please confirm access code", Toast.LENGTH_SHORT).show(); return;}
                else if (!agreeBox.isChecked()){
                    Toast.makeText(getApplicationContext(),
                            "Please agree to the Terms and Services", Toast.LENGTH_SHORT).show(); return;}
                else if (!confirmInput.getText().toString().matches(accessInput.getText().toString())){
                    Toast.makeText(getApplicationContext(),
                            "Please ensure that the code confirmation is inputted " +
                                    "correctly", Toast.LENGTH_SHORT).show(); return;}
                else if (!idCheck){
                    Toast.makeText(getApplicationContext(), "Not a valid Employee ID",
                            Toast.LENGTH_SHORT).show(); return;
                }

                Toast.makeText(getApplicationContext(), "Form submitted successfully.",
                        Toast.LENGTH_SHORT).show();

            }
        });

        linear_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RelativeLayoutActivity.this, LinearLayoutActivity.class);
                startActivity(intent);
            }
        });


        // Sends user to RelativeLayput on click of RelativeButton
        relative_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RelativeLayoutActivity.this, RelativeLayoutActivity.class);
                startActivity(intent);
            }
        });

        // Sends user to TableLayout on click of TableButton
        table_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RelativeLayoutActivity.this, TableLayoutActivity.class);
                startActivity(intent);
            }
        });

        //Toast.makeText(getApplicationContext(), "Returned fully", Toast.LENGTH_SHORT).show();

    }
}
