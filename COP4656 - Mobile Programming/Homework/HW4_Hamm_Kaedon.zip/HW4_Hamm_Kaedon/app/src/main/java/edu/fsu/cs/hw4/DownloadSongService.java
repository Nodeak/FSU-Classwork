package edu.fsu.cs.hw4;

import android.app.DownloadManager;
import android.app.IntentService;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.widget.Toast;
import android.content.Context;

import java.io.File;
import java.net.URL;

public class DownloadSongService extends IntentService {
    private static final String ACTION_DOWNLOAD = "edu.fsu.cs.hw4.action.DOWNLOAD";
    private static final String EXTRA_URL = "edu.fsu.cs.hw4.extra.URL";
    String download_url;
    String dl_path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).toString();
    static DownloadManager dm;


    public DownloadSongService() {
        super("DownloadSongService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        download_url = intent.getStringExtra("download_url");
        Uri uri = Uri.parse(download_url);

        if (intent != null) {
            final String action = intent.getAction();
            if (ACTION_DOWNLOAD.equals(action)) {
                final String url = intent.getStringExtra(EXTRA_URL);

                DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                DownloadManager.Request request = new DownloadManager.Request(uri);
                request.setTitle(download_url);
                request.setDescription("Downloading...");
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setVisibleInDownloadsUi(true);
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, download_url + ".mp3");
                dm.enqueue(request);

                Log.d("DownloadActivity", "downloadReceiver intent called");
                NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                Intent media_intent = new Intent(DownloadSongService.this, MyMediaService.class);
                media_intent.setData(uri);
                media_intent.putExtra("filename", download_url);
                media_intent.putExtra("pathname", dl_path);
                PendingIntent pIntent = PendingIntent.getService(getApplicationContext(), 0, media_intent,
                        PendingIntent.FLAG_UPDATE_CURRENT);

                Notification.Builder cBuilder = new Notification.Builder(getApplicationContext())
                        .setSmallIcon(R.drawable.cdalbumsmall)
                        .setAutoCancel(false)
                        .setContentTitle(download_url)
                        .setContentText("Complete.")
                        .setWhen(System.currentTimeMillis())
                        .setContentIntent(pIntent);

                nm.notify(1, cBuilder.build());

            }
        }
    }

    private BroadcastReceiver downloadReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {

        }
    };


}