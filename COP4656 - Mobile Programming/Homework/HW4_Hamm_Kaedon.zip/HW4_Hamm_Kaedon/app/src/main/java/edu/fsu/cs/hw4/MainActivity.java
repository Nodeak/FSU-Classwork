package edu.fsu.cs.hw4;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.IntentService;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.provider.Telephony;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getCanonicalName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // TODO setup UI
        ImageButton playButton = (ImageButton) findViewById(R.id.play_image_button);
        ImageButton stopButton = (ImageButton) findViewById(R.id.stop_button);
        ImageView albumArt = (ImageView) findViewById(R.id.album_image);
        TextView artistName = (TextView) findViewById(R.id.artist_title);
        TextView songName = (TextView) findViewById(R.id.song_title);

        songName.setText("N/A");
        artistName.setText("N/A");
        // TODO Do we need to handle any Extras?

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()) {
            case R.id.download:
                // Open ContextMenu
                LayoutInflater lay_inf = LayoutInflater.from(this);
                View promptsView = lay_inf.inflate(R.layout.prompt, null);

                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
                alertDialogBuilder.setView(promptsView);

                final EditText userInput = (EditText) promptsView
                        .findViewById(R.id.editTextDialogUserInput);

                // set dialog message
                alertDialogBuilder
                        .setCancelable(true)
                        .setNeutralButton(R.string.submit, new DialogInterface.OnClickListener(){
                            public void onClick(DialogInterface dialog, int id){
                                // TODO: Implement Download Song Service Here
                                Log.i("Click", "Initiate Download.");
                                String download_url = userInput.getText().toString();
                                Intent intent = new Intent(MainActivity.this, DownloadSongService.class);
                                intent.putExtra("download_url", download_url);
                                intent.setAction("edu.fsu.cs.hw4.action.DOWNLOAD");
                                startService(intent);
                            }
                        });
                // create alert dialog
                AlertDialog alertDialog = alertDialogBuilder.create();
                // show it
                alertDialog.show();

                break;
            case R.id.exit:
                finish();
                break;
        }
        return true;
    }


    // onClick method for Play button
    public void play(View v) {
        // TODO play MediaPlayer
    }

    // onclick method for Pause button
    public void pause(View v) {
        // TODO pause MediaPlayer
    }

    // onClick method for Stop button
    public void stop(View v) {
        // TODO stop MediaPlayer
    }

}