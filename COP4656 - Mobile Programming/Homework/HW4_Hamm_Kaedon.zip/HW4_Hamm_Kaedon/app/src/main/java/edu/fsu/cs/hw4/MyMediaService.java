package edu.fsu.cs.hw4;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.IBinder;
import android.util.Log;

import java.io.File;

public class MyMediaService extends Service {
    String pathname;
    String filename;
    File file;

    public MyMediaService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO Might need to modify depending on Service implementation
        Log.i("PLAYER", "Entered onBind");
        pathname = intent.getStringExtra("pathname");
        filename = intent.getStringExtra("filename");
        file = new File(pathname + filename);
        Log.i("PLAYER", "new filename = " + file.toString());
        return null;
    }

    @Override
    public void onCreate() {
        Log.i("PLAYER", "onCreate");
        super.onCreate(); }

    public void loadPlayer(String fileuri) {
        // TODO prepare MediaPlayer with fileuri
        Log.i("PLAYER", "Entered loadPlayer");
        Uri URI = Uri.fromFile(file);
        MediaPlayer mp = MediaPlayer.create(this, URI);
        mp.start();
        for(int i = 0; i < 100000000; i++) ;
        try{
            mp.seekTo(0);
        }
        catch (IllegalStateException e) { }
        for(int i = 0; i < 50000000; i++) ; mp.stop();
        mp.release();
    }
}